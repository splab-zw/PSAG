This supplementary file provides the ESA (Economic Short Answer) dataset

**Overview:** 
This dataset is derived from real examinations for the Intermediate Economic Professional Qualification, focusing on Economic Law (ESA).
 -Number of Samples: 1,500 
 -Number of Unique Questions: 3

Each sample contains four fields:
 -question - The exam question.
 -reference answer - The official reference answer.
 -student answer - The student-provided answer.
 -label - Binary label: 1 for completely correct, 0 for incorrect or partially correct.

The dataset is stored in Python pickle format (data.pkl). To load it, Python's built-in "pickle" package is required.
########################################
**Usage:**
 -Automated answer scoring
 -Educational AI and tutoring systems
 -NLP research on evaluation and understanding of student responses
