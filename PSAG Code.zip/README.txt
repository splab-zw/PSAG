This repository contains the core code used in our manuscript 

Core Components
---------------
1. Data Processing and Training Split (Example: DPP)
   - Implements Determinantal Point Process (DPP) to select Initial Labeled           Samples.

2. Initial Rule Construction
   - Scripts for generating the initial set of rules.
   - Pretrain a rule generator using the Initial Rule Set.
   - Pretrain a rule Evaluator using the Initial Labeled Samples.

3. EM Iterative Process
   - Implementation of the core Expectation-Maximization (EM) procedure 
     for refining pattern-semantics alignment.

Usage Notes
-----------
- The code demonstrates the core innovations of PSAG.
- Users should replace model paths and data paths with their own local files.
- Using these scripts, one can obtain high-quality pseudo-labeled samples from a given dataset, following the full generator-evaluator EM loop.
- The grading model is fine-tuned on both the initial labeled samples and the high-quality pseudo-labeled samples. Any classification or NLI backbone can be used; explicit code is not provided since the fine-tuning process is standard and backbone-agnostic.