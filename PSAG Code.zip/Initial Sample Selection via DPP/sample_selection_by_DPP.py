"""
Core script for initial sample selection using DPP (Determinantal Point Process).
This code demonstrates key innovations of PSAG, including:
1. DPP-based initial sample selection.
2. Balanced and unbalanced sample selection from grouped data.
"""

import torch
import numpy as np
from transformers import AutoTokenizer, AutoModel
from dppy.finite_dpps import FiniteDPP
import pickle
from collections import defaultdict
from tqdm import tqdm

# ----------------------
# Configuration
# ----------------------
NUM_SAMPLES = 10
MODEL_PATH = "path_to_your_model_directory_or_huggingface_model_name"
DATA_PATH = "path_to_your_data_pickle_file"

# ----------------------
# Utility Functions
# ----------------------
def mean_pooling(model_output, attention_mask):
    """
    Perform mean pooling on token embeddings to obtain sentence embeddings.
    """
    token_embeddings = model_output.last_hidden_state
    mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * mask_expanded, 1) / torch.clamp(mask_expanded.sum(1), min=1e-9)

def encode_texts(tokenizer, model, texts):
    """
    Encode a list of texts into embeddings using a Transformer model.
    """
    encoded_input = tokenizer(texts, padding=True, truncation=True, return_tensors='pt')
    with torch.no_grad():
        model_output = model(**encoded_input, return_dict=True)
    embeddings = mean_pooling(model_output, encoded_input['attention_mask'])
    return embeddings.cpu().numpy()

def load_data(data_path):
    """
    Load data from a pickle file and group by question.
    """
    with open(data_path, 'rb') as f:
        all_data = pickle.load(f)

    groups = defaultdict(list)
    for q, r, a, l in all_data:
        groups[q].append((q, r, a, l))
    return dict(groups)

# ----------------------
# DPP Sampling
# ----------------------
def dpp_sample(data, num_samples, tokenizer, model):
    """
    Perform DPP sampling on a set of data items based on text embeddings.
    """
    texts = [item[2] for item in data]  # extract text content
    embeddings = encode_texts(tokenizer, model, texts)

    # Compute similarity matrix (using inner product, can approximate cosine similarity)
    similarity_matrix = np.matmul(embeddings, embeddings.T)

    # Construct DPP and sample subset
    dpp = FiniteDPP('likelihood', L=similarity_matrix)
    dpp.flush_samples()
    dpp.sample_exact_k_dpp(size=num_samples)
    selected_indices = dpp.list_of_samples[0]
    return [data[i] for i in selected_indices]

# ----------------------
# Sample Selection Strategies
# ----------------------
def balanced_selection(groups, num_samples, tokenizer, model):
    """
    Perform balanced selection: sample equal number of items per class per question.
    """
    train_set, test_set = [], []

    for q, items in tqdm(groups.items(), desc="Balanced multi-class selection"):
        # 按类别分组
        label_groups = defaultdict(list)
        for item in items:
            label_groups[item[3]].append(item)

        selected_items = []
        for label, label_items in label_groups.items():
            k = min(num_samples, len(label_items))
            if k > 0:
                selected_items.extend(dpp_sample(label_items, k, tokenizer, model))

        train_set.extend(selected_items)
        remaining = set(items) - set(selected_items)
        test_set.extend(list(remaining))

    return train_set, test_set

def unbalanced_selection(groups, num_samples, tokenizer, model):
    """
    Perform unbalanced selection:
    sample a fixed number of items per question, regardless of label distribution.
    """
    train_set, test_set = [], []

    for q, items in tqdm(groups.items(), desc="Unbalanced multi-class selection"):
        # 按类别分组
        label_groups = defaultdict(list)
        for item in items:
            label_groups[item[3]].append(item)

        selected_items = []
        for label, label_items in label_groups.items():
            k = min(num_samples, len(label_items))  # 每个类别采样 num_samples 条
            if k > 0:
                selected_items.extend(dpp_sample(label_items, k, tokenizer, model))

        train_set.extend(selected_items)
        remaining = set(items) - set(selected_items)
        test_set.extend(list(remaining))

    return train_set, test_set

# ----------------------
# Main Execution
# ----------------------
def main():
    # Load tokenizer and model
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
    model = AutoModel.from_pretrained(MODEL_PATH)

    # Load and group data
    groups = load_data(DATA_PATH)

    # Sample selection (choose either balanced or unbalanced)
    train_set, test_set = balanced_selection(groups, NUM_SAMPLES, tokenizer, model)

    print(f"Train size: {len(train_set)}, Test size: {len(test_set)}")

    # Save sampled data
    with open('Train.pkl', 'wb') as f:
        pickle.dump(train_set, f)
    with open('Test.pkl', 'wb') as f:
        pickle.dump(test_set, f)

if __name__ == "__main__":
    main()
