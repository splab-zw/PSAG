# =============================
# EM Iterative Training Process
# =============================

import pickle
import random
import time
from collections import defaultdict
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from transformers import BartTokenizer, BartForConditionalGeneration, AutoTokenizer, AutoModel
from config import *
from utils.rule import generate_rules, label_by_rules, compute_high_quality_rules, embed_texts
from utils.knn import select_high_quality_by_knn_balanced, filter_and_dedup
from utils.lemmatize import lemmatize_texts, lemmatize_rule, lemmatize_rules_list
from utils.TrainGenerator import train_generator_on_model
from utils.TrainEvaluator import train_evaluator_on_model, SBERTContrastive


def run_EM_iterations(
    TRAIN_DATA_PATH, TEST_DATA_PATH,
    PRETRAINED_GENERATOR_PATH, PRETRAINED_EVALUATOR_PATH,
    MAX_ITERATIONS, MAX_INPUT_LENGTH, MAX_RULE_LENGTH, BEAM_SIZE,
    ALPHA, TOP_RATIO, MIN_RULE_LENGTH, K_POS, K_NEG,
    DEVICE, HIDDEN_DIM
):
    """
    EM iterative training loop.
    Both Generator and Evaluator are initialized and updated incrementally.
    """

    # -----------------------------
    # Initialize Generator & Evaluator
    # -----------------------------
    generator_tokenizer = BartTokenizer.from_pretrained(PRETRAINED_GENERATOR_PATH)
    generator_model = BartForConditionalGeneration.from_pretrained(PRETRAINED_GENERATOR_PATH).to(DEVICE)

    evaluator_tokenizer = AutoTokenizer.from_pretrained(PRETRAINED_EVALUATOR_PATH)
    evaluator_model = SBERTContrastive(sbert_path=PRETRAINED_EVALUATOR_PATH, hidden_dim=HIDDEN_DIM).to(DEVICE)
    evaluator_model.mlp.load_state_dict(torch.load(f"{PRETRAINED_EVALUATOR_PATH}/mlp.pt", map_location=DEVICE))
    evaluator_model.eval()

    # Load training and testing datasets
    with open(TRAIN_DATA_PATH, 'rb') as f:
        Train = pickle.load(f)
    with open(TEST_DATA_PATH, 'rb') as f:
        Test = pickle.load(f)
    print(f"Train samples: {len(Train)}, Test samples: {len(Test)}")

    # -----------------------------
    # Group data by question ID
    # -----------------------------
    train_by_q = defaultdict(list)
    for t in Train:
        train_by_q[t[0]].append(t)

    test_by_q = defaultdict(list)
    for t in Test:
        test_by_q[t[0]].append(t)

    # Lemmatize answers in the test set for rule matching
    all_a = [t[2] for t in Test]
    all_a_lemmatized = lemmatize_texts(all_a)
    Test_lemma = [(q, r, " ".join(a_), l) for (q, r, a, l), a_ in zip(Test, all_a_lemmatized)]
    test_by_q_lemma = defaultdict(list)
    for t in Test_lemma:
        test_by_q_lemma[t[0]].append(t)

    # -----------------------------
    # Initialize sample pool
    # -----------------------------
    sample_pool = [ (t[0], t[1], t[2], t[3]) for t in Train ]
    train_size = len(sample_pool)

    high_quality_pseudo_labeled_samples = []
    high_quality_rules = []

    start = time.time()
    for iteration in range(MAX_ITERATIONS):
        print(f"\n=== Iteration {iteration + 1} ===")

        generator_train_data = []
        evaluator_train_data = []

        # Sample data from sample_pool for this iteration
        sampled_data = random.sample(sample_pool, k=train_size)
        train_by_q_iter = defaultdict(list)
        for q_id, r, a, l in sampled_data:
            train_by_q_iter[q_id].append((q_id, r, a, l))

        # -----------------------------
        # Iterate over each question
        # -----------------------------
        for q_id, group_train in train_by_q_iter.items():
            group_test = test_by_q[q_id]
            group_test_lemmatized = test_by_q_lemma[q_id]

            # Positive examples for generator training
            pos_texts = [t[2] for t in group_train if t[3] == 1]
            test_texts = [t[2] for t in group_test]
            test_texts_lemmatized = [t[2] for t in group_test_lemmatized]
            test_refs = [t[1] for t in group_test]

            # -----------------------------
            # Generate candidate rules using Generator
            # -----------------------------
            rules_list, log_probs_list = generate_rules(
                generator_model,
                generator_tokenizer,
                pos_texts,
                max_input_len=MAX_INPUT_LENGTH,
                max_output_len=MAX_RULE_LENGTH+2, # account for <s> tokens
                beam_size=BEAM_SIZE,
                device=DEVICE
            )

            # Lemmatize generated rules for consistent matching
            rules_list_lemma = lemmatize_rules_list(rules_list)
            rules_list_lemma_str = [
                [" ".join(rule) if isinstance(rule, list) else rule for rule in group]
                for group in rules_list_lemma
            ]

            # -----------------------------
            # Select high-quality rules and prepare generator training pairs
            # -----------------------------
            selected_rules, pairs_for_train = compute_high_quality_rules(
                pos_texts,
                rules_list_lemma_str,
                log_probs_list,
                test_texts_lemmatized,
                ALPHA,  # weighting factor
                TOP_RATIO,  # top rules ratio
                MIN_RULE_LENGTH,  # minimum rule length
                evaluator_model,
                evaluator_tokenizer,
                DEVICE
            )

            generator_train_data.extend(pairs_for_train)
            high_quality_rules.extend(selected_rules)
            print(f"Selected high-quality rules: {len(selected_rules)}")

            # -----------------------------
            # Pseudo-label test examples using selected rules & filter with KNN
            # -----------------------------
            pseudo_labels = label_by_rules(test_texts_lemmatized, selected_rules)
            embed_fn = lambda texts: embed_texts(texts, evaluator_model, evaluator_tokenizer, device=DEVICE)

            selected_idx, selected_pos_num, selected_neg_num = select_high_quality_by_knn_balanced(
                test_texts, pseudo_labels, embed_fn, k_pos=K_POS, k_neg=K_NEG
            )
            print(f"Selected pos: {selected_pos_num}, neg: {selected_neg_num}")

            # Collect selected samples
            selected_samples = [
                (q_id, test_refs[idx], test_texts[idx], int(pseudo_labels[idx]))
                for idx in selected_idx
            ]

            # Handle conflicts and deduplicate
            selected_samples, high_quality_pseudo_labeled_samples = filter_and_dedup(
                high_quality_pseudo_labeled_samples, selected_samples
            )
            print(f"Current high-quality samples: {len(high_quality_pseudo_labeled_samples)}")

            # Add selected samples back to sample pool
            sample_pool.extend(selected_samples)
            sample_pool = list(set(sample_pool))  # deduplicate
            evaluator_train_data.extend(selected_samples)

        # -----------------------------
        # Incrementally train Evaluator
        # -----------------------------
        if evaluator_train_data:
            evaluator_train_data.extend(Train)
            stop_iteration = train_evaluator_on_model(
                evaluator_model,
                evaluator_tokenizer,
                evaluator_train_data,
                temperature=TEMPERATURE,
                device=DEVICE
            )
            if not stop_iteration:
                print("Early stopping: not enough training data.")
                break

        # -----------------------------
        # Incrementally train Generator
        # -----------------------------
        if generator_train_data:
            train_generator_on_model(
                generator_model,
                generator_tokenizer,
                generator_train_data,
                max_input_len=MAX_INPUT_LENGTH,
                max_output_len=MAX_RULE_LENGTH+2,
                device=DEVICE
            )

    # -----------------------------
    # End of EM iterations
    # -----------------------------
    end = time.time()
    print(f"EM iterations finished. Runtime: {end - start:.2f}s")
    print(f"Final high-quality samples: {len(high_quality_pseudo_labeled_samples)}")
    print(f"Final high-quality rules: {len(high_quality_rules)}")

    # Save results
    with open("generated_rules.pkl", "wb") as f:
        pickle.dump(high_quality_rules, f)
    with open("high_quality_samples.pkl", "wb") as f:
        pickle.dump(high_quality_pseudo_labeled_samples, f)


def main():
    """
    Entry point to run EM iterative training.
    """
    run_EM_iterations(
        TRAIN_DATA_PATH=TRAIN_DATA_PATH,
        TEST_DATA_PATH=TEST_DATA_PATH,
        PRETRAINED_GENERATOR_PATH=PRETRAINED_GENERATOR_PATH,
        PRETRAINED_EVALUATOR_PATH=PRETRAINED_EVALUATOR_PATH,
        MAX_ITERATIONS=MAX_ITERATIONS,
        MAX_INPUT_LENGTH=MAX_INPUT_LENGTH,
        MAX_RULE_LENGTH=MAX_RULE_LENGTH,
        BEAM_SIZE=BEAM_SIZE,
        ALPHA=ALPHA,
        TOP_RATIO=TOP_RATIO,
        MIN_RULE_LENGTH=MIN_RULE_LENGTH,
        K_POS=K_POS,
        K_NEG=K_NEG,
        DEVICE=DEVICE,
        HIDDEN_DIM=HIDDEN_DIM
    )

if __name__ == "__main__":
    main()
