# =============================
# config.py
# =============================

import torch
import random
import numpy as np

# -----------------------------
# Random Seed
# -----------------------------
# Fix the random seed for reproducibility
SEED = 42
torch.manual_seed(SEED)
torch.cuda.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)
random.seed(SEED)
np.random.seed(SEED)

# -----------------------------
# Device
# -----------------------------
DEVICE = "your_device"   # e.g., "cuda:0" or "cpu"

# -----------------------------
# Dataset & Paths
# -----------------------------
# Replace "your_path" with the actual dataset and model directories

TRAIN_DATA_PATH = "your_path/Train.pkl"
TEST_DATA_PATH  = "your_path/Test.pkl"

PRETRAINED_GENERATOR_PATH   = "your_path/pretrained-generator"
PRETRAINED_EVALUATOR_PATH   = "your_path/pretrained-evaluator"

# -----------------------------
# Training Hyperparameters
# -----------------------------
# Input/output sequence lengths
MAX_INPUT_LENGTH = 128
MIN_RULE_LENGTH = 7
MAX_RULE_LENGTH = 10

# Decoding strategies
BEAM_SIZE = 10
ALPHA = 0.3
TOP_RATIO = 0.5

# Number of positive and negative samples
K_POS = 8
K_NEG = 10

# Model dimensions and training iterations
TEMPERATURE = 0.9
HIDDEN_DIM = 256
MAX_ITERATIONS = 5
