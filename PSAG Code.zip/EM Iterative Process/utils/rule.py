import torch
import torch.nn.functional as F

def contains_rule_in_text(text: str, rule):
    """
    Check if all words in a rule appear consecutively in the text.
    """
    words = text.split()
    rule_words = rule if isinstance(rule, list) else str(rule).split()
    idx = 0
    for w in words:
        if idx < len(rule_words) and w == rule_words[idx]:
            idx += 1
            if idx == len(rule_words):
                return True
    return False

def label_by_single_rule(texts, rule):
    """
    Label texts as 1 if they contain the rule, otherwise 0.
    """
    return [1 if contains_rule_in_text(t, rule) else 0 for t in texts]

def label_by_rules(texts, rules):
    """
    Apply multiple rules to texts. If any rule matches, label as 1.
    """
    labels = [0] * len(texts)
    for rule in rules:
        rule_labels = label_by_single_rule(texts, rule)
        labels = [max(l, r) for l, r in zip(labels, rule_labels)]
    return labels

@torch.no_grad()
def embed_texts(texts, model, tokenizer, device, batch_size=64):
    """
    Compute embeddings for a list of texts using the provided model and tokenizer.
    """
    model.eval()
    all_vecs = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i+batch_size]
        enc = tokenizer(batch, return_tensors="pt", padding=True, truncation=True).to(device)
        vec = model(enc["input_ids"], enc["attention_mask"])
        all_vecs.append(vec.detach().cpu())
    return torch.cat(all_vecs, dim=0) if all_vecs else torch.empty(0, model.mlp[-1].out_features)

def compute_rule_score(log_p_z, X_pos_texts, X_neg_texts, embed_fn, alpha):
    """
    Compute a score for a candidate rule.
    - log_p_z: log-probability of the rule from the generator
    - X_pos_texts: texts labeled positive by this rule
    - X_neg_texts: texts not covered by any rule
    - embed_fn: function to compute embeddings
    - alpha: weighting factor for log probability
    """
    if len(X_pos_texts) < 2:
        return -1e9  # too few positives, discard
    P = embed_fn(X_pos_texts)
    P = F.normalize(P, dim=1)
    sim_pp = P @ P.T
    num = P.size(0)
    pos_mean = (sim_pp.sum() - num) / (num * (num - 1))  # average similarity among positives
    if len(X_neg_texts) > 0:
        N = embed_fn(X_neg_texts)
        N = F.normalize(N, dim=1)
        sim_pn = P @ N.T
        neg_max = sim_pn.max().item()  # max similarity with negatives
    else:
        neg_max = 0.0
    return (alpha * float(log_p_z)) + float(pos_mean) - float(neg_max)

def generate_rules(generator, tokenizer, texts, max_input_len, max_output_len, beam_size, device):
    """
    Generate candidate rules for each text using the generator model.
    Returns a list of candidate rules and their log probabilities.
    """
    all_rules = []
    all_log_probs = []
    generator.eval()
    for text in texts:
        inputs = tokenizer(text, truncation=True, padding="max_length", max_length=max_input_len, return_tensors="pt").to(device)
        output = generator.generate(
            **inputs,
            max_length=max_output_len,
            num_beams=beam_size,
            num_return_sequences=beam_size,
            output_scores=True,
            return_dict_in_generate=True
        )
        sequences = tokenizer.batch_decode(output.sequences, skip_special_tokens=True)
        log_probs = output.sequences_scores.cpu().tolist()
        all_rules.append(sequences)
        all_log_probs.append(log_probs)
    return all_rules, all_log_probs

def compute_high_quality_rules(
        pos_texts,
        rules_list,
        log_probs_list,
        test_texts,
        alpha,
        top_ratio,
        min_rule_length,
        evaluator,
        evaluator_tokenizer,
        device,
):
    """
    Select high-quality rules from candidate rules.
    - pos_texts: positive texts used to generate rules
    - rules_list: candidate rules for each text
    - log_probs_list: log probabilities of each rule
    - test_texts: texts for evaluating rules
    - alpha: weight for log probability
    - top_ratio: fraction of top rules to keep
    - min_rule_length: minimum number of words in a rule
    - evaluator: embedding model for computing similarity
    """
    high_quality_rules = []
    generator_train_pairs = []

    embed_fn = lambda texts: embed_texts(texts, evaluator, evaluator_tokenizer, device)

    for i, cand_rules in enumerate(rules_list):
        source_text = pos_texts[i]
        rule_logps = log_probs_list[i]
        # Label test texts for each candidate rule
        labels_per_rule = [label_by_single_rule(test_texts, r) for r in cand_rules]

        # Identify texts not covered by any rule as negatives
        covered_by_any = [0] * len(test_texts)
        for labs in labels_per_rule:
            for k, y in enumerate(labs):
                covered_by_any[k] = 1 if (covered_by_any[k] or y) else 0
        X_neg = [test_texts[k] for k, c in enumerate(covered_by_any) if c == 0]

        # Compute score for each candidate rule
        for j, rule in enumerate(cand_rules):
            if len(rule.split()) < min_rule_length:
                continue  # skip rules that are too short

            X_pos = [test_texts[k] for k, y in enumerate(labels_per_rule[j]) if y == 1]
            score = compute_rule_score(rule_logps[j], X_pos, X_neg, embed_fn, alpha)
            high_quality_rules.append((rule, score))
            generator_train_pairs.append((source_text, rule))

    # Sort by score and select top rules
    high_quality_rules.sort(key=lambda x: x[1], reverse=True)
    cutoff = max(1, int(len(high_quality_rules) * top_ratio))
    selected_rules = [r[0] for r in high_quality_rules[:cutoff]]

    # Keep only generator training pairs corresponding to top rules
    selected_pairs = [(txt, r) for txt, r in generator_train_pairs if r in selected_rules]

    return selected_rules, selected_pairs
