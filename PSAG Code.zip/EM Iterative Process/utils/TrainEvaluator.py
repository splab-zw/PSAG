import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer, AutoModel
from collections import defaultdict
import random
import os


# ==================
# Contrastive Learning Dataset
# ==================
class ContrastiveDataset(Dataset):
    """
    Dataset for contrastive learning.
    For each question q, generates (q, positive, negative) triplets.

    Parameters:
    - data: list of tuples [(q, r, a, l), ...], where l is label (1=positive)
    - num_negatives: number of negatives sampled per positive
    """

    def __init__(self, data, num_negatives=3):
        self.pairs = []
        grouped_data = defaultdict(list)
        for q, r, a, l in data:
            grouped_data[q].append((r, a, l))

        for q, samples in grouped_data.items():
            positives = [a for r, a, l in samples if l == 1]
            negatives = [a for r, a, l in samples if l != 1]
            # Skip if no positives or negatives for this question
            if not positives or not negatives:
                continue
            for pos in positives:
                sampled_negs = random.sample(negatives, min(num_negatives, len(negatives)))
                for neg in sampled_negs:
                    self.pairs.append((q, pos, neg))

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        q, pos, neg = self.pairs[idx]
        return q, pos, neg


# ==================
# SBERT-based Contrastive Model
# ==================
class SBERTContrastive(nn.Module):
    """
    SBERT model with an MLP projection head for contrastive learning.

    Parameters:
    - sbert_path: path or name of pretrained SBERT model
    - hidden_dim: dimension of MLP output embeddings
    """

    def __init__(self, sbert_path, hidden_dim=256):
        super().__init__()
        self.encoder = AutoModel.from_pretrained(sbert_path)
        self.mlp = nn.Sequential(
            nn.Linear(self.encoder.config.hidden_size, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )

    def forward(self, input_ids, attention_mask):
        outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
        # Use pooler output if available, otherwise use [CLS] token
        if hasattr(outputs, "pooler_output"):
            x = outputs.pooler_output
        else:
            x = outputs.last_hidden_state[:, 0]
        return self.mlp(x)


# ==================
# Contrastive Loss
# ==================
def contrastive_loss(q_emb, pos_emb, neg_emb, temperature=0.9):
    """
    Compute contrastive loss for a batch of (q, positive, negative) embeddings.
    """
    sim_pos = torch.cosine_similarity(q_emb, pos_emb)
    sim_neg = torch.cosine_similarity(q_emb.unsqueeze(1), neg_emb, dim=-1)
    exp_pos = torch.exp(sim_pos / temperature)
    exp_neg = torch.exp(sim_neg / temperature).sum(dim=1)
    loss = -torch.log(exp_pos / (exp_pos + exp_neg))
    return loss.mean()


# ==================
# Incremental Training for Evaluator
# ==================
def train_evaluator_on_model(evaluator_model, evaluator_tokenizer, train_data,
                             num_negatives=3, batch_size=8, lr=2e-5,
                             num_epochs=3, temperature=0.9, device="cuda"):
    """
    Incrementally train the evaluator model on provided data.

    Parameters:
    - evaluator_model: SBERTContrastive instance
    - evaluator_tokenizer: corresponding tokenizer
    - train_data: list of tuples [(q, r, a, l), ...]
    - num_negatives: number of negatives per positive sample
    - batch_size: training batch size
    - lr: learning rate
    - num_epochs: number of epochs
    - temperature: temperature for contrastive loss
    - device: "cuda" or "cpu"

    Returns:
    - True if training occurred, False if skipped due to insufficient data
    """
    if not train_data:
        print("No evaluator training data provided. Skipping training.")
        return False

    # Create dataset and loader
    dataset = ContrastiveDataset(train_data, num_negatives=num_negatives)
    if len(dataset) == 0:
        print("Insufficient positive/negative samples. Skipping evaluator training.")
        return False
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    # Move model to device and set up optimizer
    evaluator_model.train()
    evaluator_model.to(device)
    optimizer = torch.optim.AdamW(evaluator_model.parameters(), lr=lr)

    # Training loop
    for epoch in range(num_epochs):
        total_loss = 0
        for qs, poss, negs in loader:
            # Tokenize inputs
            q_enc = evaluator_tokenizer(list(qs), return_tensors="pt", padding=True, truncation=True).to(device)
            pos_enc = evaluator_tokenizer(list(poss), return_tensors="pt", padding=True, truncation=True).to(device)
            neg_enc = evaluator_tokenizer(list(negs), return_tensors="pt", padding=True, truncation=True).to(device)

            # Forward pass
            q_emb = evaluator_model(q_enc.input_ids, q_enc.attention_mask)
            pos_emb = evaluator_model(pos_enc.input_ids, pos_enc.attention_mask)
            neg_emb = evaluator_model(neg_enc.input_ids, neg_enc.attention_mask)

            # Compute contrastive loss
            loss = contrastive_loss(q_emb, pos_emb, neg_emb, temperature)

            # Backpropagation
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        avg_loss = total_loss / len(loader)
        print(f"[Evaluator] Epoch {epoch + 1}/{num_epochs} | Average Loss: {avg_loss:.4f}")

    return True
