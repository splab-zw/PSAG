import torch
from torch.utils.data import Dataset, DataLoader
from transformers import BartTokenizer, BartForConditionalGeneration, AdamW


def train_generator_on_model(generator_model, generator_tokenizer, generator_train_data,
                             max_input_len, max_output_len,
                             batch_size=8, lr=2e-5, num_epochs=3, device="cuda"):
    """
    Incrementally train the generator model (fine-tune on top of existing model).

    Parameters:
    - generator_model: pre-initialized BART generator model
    - generator_tokenizer: corresponding tokenizer
    - generator_train_data: list of (input_text, target_rule) pairs
    - max_input_len: max token length for input
    - max_output_len: max token length for output
    - batch_size: training batch size
    - lr: learning rate
    - num_epochs: number of epochs
    - device: "cuda" or "cpu"
    """
    if not generator_train_data:
        print("No training data provided. Skipping generator training.")
        return

    # ==================
    # Dataset Definition
    # ==================
    class KeywordDataset(Dataset):
        """
        Dataset class for generator training data.
        """

        def __init__(self, data, tokenizer, max_input_len, max_output_len):
            self.data = data
            self.tokenizer = tokenizer
            self.max_input_len = max_input_len
            self.max_output_len = max_output_len

        def __len__(self):
            return len(self.data)

        def __getitem__(self, idx):
            x, k = self.data[idx]  # x: input text, k: target rule

            # Tokenize input text
            model_inputs = self.tokenizer(
                x,
                max_length=self.max_input_len,
                truncation=True,
                padding="max_length",
                return_tensors="pt"
            )

            # Tokenize target output
            labels = self.tokenizer(
                k,
                max_length=self.max_output_len,
                truncation=True,
                padding="max_length",
                return_tensors="pt"
            )["input_ids"]

            # Replace padding token IDs with -100 for loss calculation
            labels[labels == self.tokenizer.pad_token_id] = -100
            model_inputs["labels"] = labels

            # Squeeze batch dimension (DataLoader expects 1D tensors)
            return {key: val.squeeze(0) for key, val in model_inputs.items()}

    # ==================
    # DataLoader
    # ==================
    train_dataset = KeywordDataset(generator_train_data, generator_tokenizer, max_input_len, max_output_len)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

    # ==================
    # Optimizer
    # ==================
    optimizer = torch.optim.AdamW(generator_model.parameters(), lr=lr)

    # ==================
    # Training Loop
    # ==================
    generator_model.train()
    generator_model.to(device)
    for epoch in range(num_epochs):
        total_loss = 0
        for batch in train_loader:
            # Move batch to device
            batch = {k: v.to(device) for k, v in batch.items()}

            # Forward pass
            outputs = generator_model(**batch)
            loss = outputs.loss
            total_loss += loss.item()

            # Backward pass and optimization step
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        avg_loss = total_loss / len(train_loader)
        print(f"[Generator] Epoch {epoch + 1}/{num_epochs} | Average Loss: {avg_loss:.4f}")
