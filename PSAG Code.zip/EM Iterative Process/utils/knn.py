import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import pairwise_distances


def select_high_quality_by_knn_balanced(test_texts, pseudo_labels, embed_fn, k_pos, k_neg, metric='cosine'):
    """
    Select high-quality positive and negative samples based on KNN consistency.

    Parameters:
    - test_texts: list of texts to consider
    - pseudo_labels: predicted labels (0/1) for each text
    - embed_fn: function that returns embeddings for a list of texts
    - k_pos: number of positive neighbors to check
    - k_neg: number of negative neighbors to check
    - metric: distance metric for KNN (default: cosine)

    Returns:
    - selected indices (list)
    - number of selected positive samples
    - number of selected negative samples
    """
    n = len(test_texts)
    if n == 0:
        return []

    # Compute embeddings for all texts
    embs = embed_fn(test_texts)
    if not isinstance(embs, np.ndarray):
        embs = embs.detach().cpu().numpy()

    max_k = max(k_pos, k_neg)
    n_neighbors = min(max_k + 1, n)
    if n_neighbors <= 1:
        return []

    # Fit KNN on embeddings
    nbrs = NearestNeighbors(n_neighbors=n_neighbors, metric=metric).fit(embs)
    distances, indices = nbrs.kneighbors(embs)

    pos_selected, neg_selected = [], []

    # Select samples whose nearest neighbors have consistent labels
    for i in range(n):
        label_i = int(pseudo_labels[i])
        k_eff = min(k_pos if label_i == 1 else k_neg, n - 1)
        if k_eff <= 0:
            continue
        neighbors = indices[i][1:1 + k_eff]  # skip self
        if all(int(pseudo_labels[n_idx]) == label_i for n_idx in neighbors):
            if label_i == 1:
                pos_selected.append(i)
            else:
                neg_selected.append(i)

    # Balance negatives to match number of positives
    if len(pos_selected) == 0:
        return [], 0, 0
    elif len(neg_selected) > len(pos_selected):
        pos_embs = embs[pos_selected]
        neg_embs = embs[neg_selected]
        dist_matrix = pairwise_distances(neg_embs, pos_embs, metric=metric)
        min_dists = dist_matrix.min(axis=1)
        top_neg_idx = np.argsort(-min_dists)[:len(pos_selected)]  # select most distant negatives
        neg_selected = [neg_selected[i] for i in top_neg_idx]

    return pos_selected + neg_selected, len(pos_selected), len(neg_selected)


def filter_and_dedup(hq_samples, new_samples):
    """
    Filter and deduplicate new pseudo-labeled samples before adding to high-quality set.

    Steps:
    1. If a new sample (q, r, a) exists in hq_samples with a conflicting label:
       - Remove it from new_samples
       - Remove the conflicting sample from hq_samples
    2. Remove duplicates in new_samples
    3. Merge new_samples into hq_samples

    Parameters:
    - hq_samples: list of high-quality samples [(q, r, a, label), ...]
    - new_samples: newly selected samples [(q, r, a, label), ...]

    Returns:
    - filtered_new: list of new samples after filtering and deduplication
    - updated_hq: updated list of high-quality samples
    """
    # Build mapping from (q, r, a) -> label for hq_samples
    hq_map = {(q, r, a): label for q, r, a, label in hq_samples}

    filtered_new = []
    for s in new_samples:
        key = (s[0], s[1], s[2])
        if key in hq_map and hq_map[key] != s[3]:
            # Conflict: remove from high-quality map
            del hq_map[key]
        else:
            filtered_new.append(s)

    # Remove duplicates in new_samples
    filtered_new = list(set(filtered_new))

    # Update high-quality samples: original ones + filtered new samples
    updated_hq = [(q, r, a, l) for (q, r, a), l in hq_map.items()]
    updated_hq.extend(filtered_new)

    return filtered_new, updated_hq
