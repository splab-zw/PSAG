import spacy

# Load spaCy model once
nlp = spacy.load("en_core_web_sm")

def lemmatize_texts(texts):
    """
    Batch lemmatization of a list of texts.
    Returns list of list of lemmatized words.
    """
    docs = nlp.pipe(texts)
    lemmatized_texts = []
    for doc in docs:
        words = [token.lemma_.lower() for token in doc if token.is_alpha]
        lemmatized_texts.append(words)
    return lemmatized_texts

def lemmatize_rule(rule):
    """
    Lemmatize a single rule (string or list of words).
    Returns list of lemmatized words.
    """
    if isinstance(rule, str):
        doc = nlp(rule)
        return [token.lemma_.lower() for token in doc if token.is_alpha]
    elif isinstance(rule, list):
        doc = nlp(" ".join(rule))
        return [token.lemma_.lower() for token in doc if token.is_alpha]
    else:
        raise ValueError(f"Unsupported rule type: {type(rule)}")

def lemmatize_rules_list(rules_list):
    """
    Lemmatize nested list of rules, keeping the structure.
    """
    return [[lemmatize_rule(r) for r in group] for group in rules_list]