import pickle
import torch
import os
from utils.TrainEvaluator import SBERTContrastive, train_evaluator_on_model
from transformers import AutoTokenizer

# ==================
# Configuration
# ==================
device = "your device"
sbert_path = "PATH_TO_PRETRAINED_SBERT"  # placeholder for pretrained SBERT model path
train_file = "PATH_TO_YOUR /Train.pkl"    # placeholder for train data file

# ==================
# Load initial labeled data
# ==================
with open(train_file, 'rb') as f:
    Train = pickle.load(f)  # expected format: [(q, r, a, l), ...]

print(f"Total training samples: {len(Train)}")


# ==================
# Initialize tokenizer and model
# ==================
tokenizer = AutoTokenizer.from_pretrained(sbert_path)
evaluator_model = SBERTContrastive(sbert_path=sbert_path).to(device)

# ==================
# Pretrain evaluator
# ==================
trained = train_evaluator_on_model(
    evaluator_model=evaluator_model,
    evaluator_tokenizer=tokenizer,
    train_data=Train
)

# ==================
# Save pretrained evaluator
# ==================
if trained:
    save_dir = "PATH_TO_SAVE_PRETRAINED_EVALUATOR"  # placeholder for save directory
    os.makedirs(save_dir, exist_ok=True)

    # Save encoder (HuggingFace format)
    evaluator_model.encoder.save_pretrained(save_dir)
    # Save tokenizer
    tokenizer.save_pretrained(save_dir)
    # Save MLP parameters separately
    torch.save(evaluator_model.mlp.state_dict(), os.path.join(save_dir, "mlp.pt"))

    print(f"Evaluator pretrained and saved to {save_dir}")
else:
    print("Evaluator training skipped due to insufficient data.")
