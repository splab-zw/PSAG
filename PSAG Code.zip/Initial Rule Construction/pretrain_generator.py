import pickle
import torch
from transformers import BartTokenizer, BartForConditionalGeneration
from utils.TrainGenerator import train_generator_on_model

# ==================
# Configuration
# ==================
model_path = "BART-base path"  # Path to local BART model
device = "your device"

# ==================
# Load data
# ==================
# src.pkl: list of input texts
# tar.pkl: list of lists of keyword sequences (each keyword sequence is a list of words)
with open("your_path/src.pkl", "rb") as f:
    src = pickle.load(f)

with open("your_path/tar.pkl", "rb") as f:
    tar = pickle.load(f)

# ==================
# Prepare training data
# ==================
# Flatten each text and its multiple keyword sequences into individual (input, target) pairs
train_data = []
for text, keyword_list in zip(src, tar):
    if not keyword_list:  # Skip if no target sequences
        continue
    for kw_seq in keyword_list:
        # kw_seq is a list of words, e.g., ['battery', 'short', 'circuited']
        # Join into a space-separated string for the tokenizer
        kw_str = " ".join(kw_seq)
        train_data.append((text, kw_str))

print(f"Total training samples: {len(train_data)}")

# ==================
# Load model and tokenizer
# ==================
tokenizer = BartTokenizer.from_pretrained(model_path)
model = BartForConditionalGeneration.from_pretrained(model_path).to(device)

# ==================
# Train the generator
# ==================
# Incrementally fine-tune the BART generator on the training pairs
train_generator_on_model(
    generator_model=model,
    generator_tokenizer=tokenizer,
    generator_train_data=train_data,
    max_input_len=128,     # maximum input sequence length
    max_output_len=10+2    # maximum output sequence length, +2 for <s> tokens
)

# ==================
# Save the fine-tuned model
# ==================
model.save_pretrained("your_path/pretrained-generator")
tokenizer.save_pretrained("your_path/pretrained-generator")

print("Training finished. Model saved to your_path/pretrained-generator")
