"""
Core script for generating pretraining rules from labeled text data.
This code demonstrates key components of PSAG:
1. IG-based word extraction.
2. POS-based rule construction.
3. Merging and saving rules for pretraining.
"""

import pickle
from collections import defaultdict
import random
import numpy as np
import utils.ig as ig # external module for information gain word extraction
import utils.pos as pos# external module for POS-based rule generation

# ----------------------
# Configuration / Hyperparameters
# ----------------------
SEED = 34
MAX_RULE_LENGTH = 10
MIN_RULE_LENGTH = 7
TOP_K_IG_WORDS = 5  # Number of top information gain words to select per text
MAX_AUGMENTATION = 5  # Number of times to augment rules
TRAIN_DATA_PATH = "your path **/Train.pkl"  # placeholder, replace with actual path

# Set random seeds for reproducibility
random.seed(SEED)
np.random.seed(SEED)


# ----------------------
# Utility Functions
# ----------------------
def load_pickle(path):
    """Load a pickle file and return its content."""
    with open(path, 'rb') as f:
        return pickle.load(f)


def save_pickle(obj, path):
    """Save an object to a pickle file."""
    with open(path, 'wb') as f:
        pickle.dump(obj, f)


def group_data_by_label(data):
    """
    Group data by question and label.
    Returns a dict: key=question, value=[positive_list, negative_list]
    """
    grouped = defaultdict(lambda: [[], []])  # index 0=positive, 1=negative
    for q, r, a, l in data:
        if l == 1:
            grouped[q][0].append(a)
        else:
            grouped[q][1].append(a)
    return dict(grouped)

def generate_pretraining_rules(grouped_data):
    """
    Generate pretraining rules using IG word extraction and POS parsing.

    Returns:
        TARS: list of rules per positive text (generator output)
        SRCS: list of original positive texts (generator input)
        pretrained_rules: flattened list of all rules
    """
    TARS = []  # Rules per text (output of generator)
    SRCS = []  # Original positive texts (input to generator)
    pretrained_rules = []  # Flattened pretraining rule set (for use or display)

    for question, (positive, negative) in grouped_data.items():
        # Extract IG words from positive and negative examples
        ig_words_list = ig.get_ig_words(positive, negative, TOP_K_IG_WORDS)

        # Parse positive texts for POS-based rules
        parsed_texts = pos.parse(positive)
        rules_pos = pos.pos_rules_with_ig(parsed_texts, ig_words_list,
                                          max_length=MAX_RULE_LENGTH,
                                          min_length=MIN_RULE_LENGTH,
                                          max_augmentation=MAX_AUGMENTATION)

        SRCS.extend(positive)
        TARS.extend(rules_pos)
        for src_rules in rules_pos:
            for rule in src_rules:
                pretrained_rules.append(rule)

    return TARS, SRCS, pretrained_rules


# ----------------------
# Main Execution
# ----------------------
def main():
    # Load training data
    data = load_pickle(TRAIN_DATA_PATH)

    # Group data by question and label
    grouped_data = group_data_by_label(data)

    # Generate pretraining rules
    TARS, SRCS, pretrained_rules = generate_pretraining_rules(grouped_data)

    # Save results to pickle files
    save_pickle(TARS, "tar.pkl")
    save_pickle(SRCS, "src.pkl")
    save_pickle(pretrained_rules, "pretrained_rules.pkl")

if __name__ == "__main__":
    main()
