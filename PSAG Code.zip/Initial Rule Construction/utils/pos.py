"""
POS-based rule generation module for PSAG.
1. Parse sentences and extract words with specific POS tags.
2. Construct rules based on POS words and optional IG words.
3. Support masking for rule augmentation.
"""

import spacy
import numpy as np

# Load NLP Model
nlp = spacy.load("en_core_web_sm")


# ----------------------
# Functions
# ----------------------
def parse(texts, pos_tags=None):
    """
    Parse sentences and extract words of specified POS tags.

    Args:
        texts: list of sentences
        pos_tags: set of POS tags to keep (default: {"NOUN", "VERB", "ADJ", "ADV"})

    Returns:
        List of token lists per sentence
    """
    if pos_tags is None:
        pos_tags = {"NOUN", "VERB", "ADJ", "ADV"}

    parsed_texts = []
    for text in texts:
        doc = nlp(text)
        words = [token.text for token in doc if token.pos_ in pos_tags]
        parsed_texts.append(words)
    return parsed_texts


def pos_rules_with_ig(parsed_texts, ig_words_list, max_length, min_length,
                      max_augmentation, pos_tags=None):
    """
    Generate POS-based rules incorporating IG words for each text.

    Args:
        parsed_texts: list of token lists (output from parse)
        ig_words_list: list of IG words (set or list) per text
        max_length: maximum rule length
        min_length: minimum rule length
        max_augmentation: number of masked variants for long rules
        pos_tags: set of POS tags to include (default {"NOUN", "VERB", "ADJ", "ADV"})

    Returns:
        List of rules per text, each entry is a list of rule variants
    """
    if pos_tags is None:
        pos_tags = {"NOUN", "VERB", "ADJ", "ADV"}

    all_rules = []
    for idx, tokens in enumerate(parsed_texts):
        ig_words = set(ig_words_list)  # IG words for current text
        sentence = " ".join(tokens)
        doc = nlp(sentence)

        # Keep words either in IG set or matching POS, preserve order, remove duplicates
        filtered = []
        seen = set()
        for token in doc:
            w = token.text
            if w in seen:
                continue
            if w in ig_words or token.pos_ in pos_tags:
                filtered.append(w)
                seen.add(w)

        length = len(filtered)
        if length < min_length:
            all_rules.append([])
            continue

        if length > max_length:
            size_to_mask = length - max_length
            n_aug = min(max_augmentation, size_to_mask)

            def mask(lst, size):
                idxs = np.random.choice(len(lst), size=size, replace=False)
                return [w for i, w in enumerate(lst) if i not in idxs]

            rules = [mask(filtered, size_to_mask) for _ in range(n_aug)]
        else:
            rules = [filtered]

        all_rules.append(rules)

    return all_rules
