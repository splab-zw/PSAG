"""
IG-based word extraction and rule generation module for PSAG.
1. Compute top-K information gain words for positive vs negative examples.
2. Construct rules from positive texts based on IG words with optional masking for augmentation.
"""

import random
import math
import numpy as np

# ----------------------
# Functions
# ----------------------
def get_ig_words(positive_texts, negative_texts, top_k):
    """
    Compute top-K information gain words from positive and negative examples.

    Args:
        positive_texts: list of positive sentences
        negative_texts: list of negative sentences
        top_k: number of top IG words to select

    Returns:
        List of top-K IG words
    """

    def entropy(labels):
        """Compute binary entropy of a label vector."""
        p1 = sum(labels) / len(labels)
        p0 = 1 - p1
        return -p1 * math.log(p1 + 1e-9) - p0 * math.log(p0 + 1e-9)

    def conditional_entropy(samples, labels, word):
        """
        Compute conditional entropy H(Y|X=word presence)
        """
        sv1 = sy1v1 = sy0v1 = sv0 = sy1v0 = sy0v0 = 0
        for i in range(len(samples)):
            sample_words = samples[i].split()
            if word in sample_words:
                sv1 += 1
                if labels[i] == 1:
                    sy1v1 += 1
                else:
                    sy0v1 += 1
            else:
                sv0 += 1
                if labels[i] == 1:
                    sy1v0 += 1
                else:
                    sy0v0 += 1
        # Compute probabilities for present
        py1v1 = sy1v1 / sv1 if sv1 > 0 else 0
        py0v1 = sy0v1 / sv1 if sv1 > 0 else 0
        pv1 = sv1 / len(labels)
        cond1 = -(py0v1 * math.log(py0v1 + 1e-9)) - (py1v1 * math.log(py1v1 + 1e-9))
        # Compute probabilities for absent
        py1v0 = sy1v0 / sv0 if sv0 > 0 else 0
        py0v0 = sy0v0 / sv0 if sv0 > 0 else 0
        pv0 = sv0 / len(labels)
        cond2 = -(py0v0 * math.log(py0v0 + 1e-9)) - (py1v0 * math.log(py1v0 + 1e-9))
        return pv1 * cond1 + pv0 * cond2

    def information_gain(samples, labels, word):
        """Compute IG(Y; word) = H(Y) - H(Y|word presence)"""
        H = entropy(labels)
        C = conditional_entropy(samples, labels, word)
        return H - C

    # Combine positive and negative samples
    samples = positive_texts + negative_texts
    labels = [1] * len(positive_texts) + [0] * len(negative_texts)

    # Collect unique vocabulary from positive texts
    vocab = set(word for sentence in positive_texts for word in sentence.split())

    # Compute IG for each word
    ig_scores = {word: round(information_gain(samples, labels, word), 6) for word in vocab}

    # Select top-K words
    top_words = sorted(ig_scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
    return [word for word, _ in top_words]


def ig_rules(src_texts, ig_words, max_length,
             min_length, max_augmentation):
    """
    Generate rules from source texts based on IG words, with optional masking for augmentation.

    Args:
        src_texts: list of positive sentences
        ig_words: list of IG words to consider
        max_length: maximum rule length
        min_length: minimum rule length
        max_augmentation: number of masked variants to generate for long rules

    Returns:
        List of rules per text. Each entry is a list of rule variants.
    """

    def mask_words(words, n_mask):
        """Randomly mask n words from the list"""
        idx = np.random.choice(len(words), size=n_mask, replace=False)
        return [w for i, w in enumerate(words) if i not in idx]

    rules_per_text = []
    for text in src_texts:
        # Keep only unique words that are in IG words
        rule = list(dict.fromkeys(w for w in text.split() if w in ig_words))
        if len(rule) < min_length:
            continue  # skip too short rules
        if len(rule) > max_length:
            size_to_mask = len(rule) - max_length
            # Generate masked variants for augmentation
            masked_versions = [mask_words(rule, size_to_mask)[:max_length]
                               for _ in range(min(max_augmentation, size_to_mask))]
            rules_per_text.append(masked_versions)
        else:
            rules_per_text.append([rule])
    return rules_per_text